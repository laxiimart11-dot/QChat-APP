# QChat — Google Play Store Upload & Mobile Installation Guide
## প্লে স্টোর আপলোড ও মোবাইল ইনস্টলেশন নির্দেশিকা

---

### ১. মোবাইলে সরাসরি ইনস্টল করার উপায় (Direct Mobile Installation / PWA)
আপনার অ্যান্ড্রয়েড ফোন বা আইফোনে কোনো ফাইল ডাউনলোড করা ছাড়াই সরাসরি আসল অ্যাপের মতো ইনস্টল করা যাবে:

#### অ্যান্ড্রয়েড (Android - Chrome / Samsung Internet / Edge):
1. আপনার ফোনে ক্রোম ব্রাউজারে অ্যাপটির লিঙ্কটি ওপেন করুন:
   `https://ais-pre-yek2ndeu5s4fqu2uhhikvm-756728280730.asia-southeast1.run.app`
2. স্ক্রিনের নিচে বা অ্যাপের মেনুতে **"📱 Install App / ইনস্টল করুন"** বাটনে ট্যাপ করুন।
3. অথবা ব্রাউজারের উপরে ৩-ডটে ক্লিক করে **"Install app"** বা **"Add to Home screen"** চাপুন।
4. সাথে সাথে আপনার ফোনের অ্যাপ ড্রয়ার এবং হোম স্ক্রিনে **QChat** আইকন যুক্ত হয়ে যাবে এবং এটি ফুল-স্ক্রিন নেটিভ অ্যাপের মতো চলবে।

#### আইফোন (iPhone / iPad - Safari):
1. সাফারিতে লিঙ্কটি ওপেন করুন।
2. নিচের **Share (শেয়ার)** আইকনে ট্যাপ করুন।
3. নিচে স্ক্রল করে **"Add to Home Screen"** সিলেক্ট করুন এবং **"Add"** চাপুন।

---

### ২. গুগল প্লে স্টোরে আপলোড করার জন্য তৈরি ফাইলসমূহ (Play Store Files Provided)

আপনার প্রজেক্টে গুগল প্লে স্টোরের প্রয়োজনীয় সমস্ত কনফিগারেশন ফাইল প্রস্তুত করে দেওয়া হয়েছে:

| ফাইলের নাম | বিবরণ |
|---|---|
| `/android/twa-manifest.json` | Google Bubblewrap TWA কনফিগারেশন ফাইল (Package: `com.qchat.messenger`) |
| `/android/app/src/main/AndroidManifest.xml` | সম্পূর্ণ অ্যান্ড্রয়েড ম্যানিফেস্ট (Camera, Audio, GPS, Notifications অনুমতি সহ) |
| `/android/app/build.gradle` | Android SDK 35 (Android 15) কম্প্যাটিবল বিল্ড ফাইল |
| `/public/.well-known/assetlinks.json` | Digital Asset Links (প্লে স্টোরে অ্যাপের ফুল-স্ক্রিন নেটিভ ভিউয়ের জন্য) |
| `/public/pwa-512x512.png` | Play Store হাই-রেজোলিউশন আইকন (512x512) |
| `/public/pwa-maskable-512x512.png` | অ্যান্ড্রয়েড অ্যাডাপ্টিভ/মাস্কেবল আইকন |
| `/android/playstore-metadata.json` | প্লে স্টোর লিস্টিং টাইটেল, শর্ট ও লং ডেসক্রিপশন |

---

### ৩. Google Play Store-এর জন্য `.aab` (Android App Bundle) তৈরির ২টি সহজ পদ্ধতি

#### পদ্ধতি ১: PWABuilder (সবচেয়ে সহজ ও দ্রুত — মাত্র ২ মিনিটে)
1. আপনার কম্পিউটার ব্রাউজারে যান: **[https://www.pwabuilder.com](https://www.pwabuilder.com)**
2. বক্সে আপনার অ্যাপের URL টি লিখুন:
   `https://ais-pre-yek2ndeu5s4fqu2uhhikvm-756728280730.asia-southeast1.run.app`
3. **"Start"** বাটনে ক্লিক করুন।
4. PWABuilder আপনার সমস্ত PWA কনফিগারেশন স্বয়ংক্রিয়ভাবে গ্রিন (100% Pass) দেখাবে।
5. **"Package for Stores"**-এ ক্লিক করে **"Android"** সিলেক্ট করুন।
6. আপনার Package ID দিন: `com.qchat.messenger`
7. **"Generate"** বাটনে ক্লিক করলেই আপনার সাইনড **`.aab`** ফাইল ডাউনলোড হয়ে যাবে!

#### পদ্ধতি ২: Bubblewrap CLI (অফিসিয়াল গুগল কমান্ড লাইন টুল)
আপনার কম্পিউটারের টার্মিনালে নিচের কমান্ডগুলো চালান:

```bash
# ১. Bubblewrap টুলটি ইন্সটল করুন
npm install -g @bubblewrap/cli

# ২. প্রজেক্টের android ফোল্ডার থেকে ইনিশিয়ালাইজ করুন
bubblewrap init --manifest="https://ais-pre-yek2ndeu5s4fqu2uhhikvm-756728280730.asia-southeast1.run.app/manifest.json"

# ৩. সাইনড Play Store AAB তৈরি করুন
bubblewrap build
```
এটি আপনাকে `app-release-signed.aab` ফাইল তৈরি করে দেবে।

---

### ৪. Google Play Console-এ আপলোড করার নিয়ম

1. **Google Play Console**-এ লগইন করুন (`play.google.com/console`)।
2. **"Create app"** বাটনে ক্লিক করুন:
   - App name: **QChat - Real-time Messenger**
   - Default language: **English (United States)** অথবা **Bengali**
   - App or game: **App**
   - Free or paid: **Free**
3. **App Content & Policies**:
   - Privacy Policy URL দিন:
     `https://ais-pre-yek2ndeu5s4fqu2uhhikvm-756728280730.asia-southeast1.run.app`
   - Content rating: All Ages / Everyone
   - Target audience: 13+
4. **Store Listing (স্টোর লিস্টিং)**:
   - `/android/playstore-metadata.json` ফাইলের ভেতরে দেওয়া Short description ও Full description কপি করে পেস্ট করুন।
   - আইকন হিসেবে আপলোড করুন: `/public/pwa-512x512.png`
   - ৫-৬টি স্ক্রিনশট আপলোড করুন।
5. **Release Management**:
   - **Production** অথবা **Closed Testing** ট্র্যাকে যান।
   - **"Create new release"** চাপুন।
   - পদ্ধতি ১ বা ২ দিয়ে তৈরি করা **`.aab`** ফাইলটি ড্র্যাগ করে আপলোড করে দিন।
   - **"Review release"** ও **"Start rollout"** চাপুন।
6. গুগল আপনার অ্যাপ রিভিউ করে ২৪ থেকে ৪৮ ঘণ্টার মধ্যে গুগল প্লে স্টোরে লাইভ করে দেবে!
